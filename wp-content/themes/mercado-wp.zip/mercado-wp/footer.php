<?php wp_footer(); ?>
    <div id="footer">
        <div class="container-fluid">
                    <p>The site is developed and maintained by the Operational Change - Intranet Team</p>
        </div>
    </div>
</body>
</html>
